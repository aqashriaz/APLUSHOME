<br><br>
Welcome to A+ Home Care! 
<br>
Your OTP Verification Code is:
<br><br>
OTP : {{$email_data['number']}}

<br><br>
Thank you!
<br>

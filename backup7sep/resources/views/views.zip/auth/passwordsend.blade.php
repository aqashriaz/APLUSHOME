<br><br>
Welcome to A+ Home Care! 
<br>
Your Login Details are following:
<br><br>
Email:  {{$email_data['email']}}
<br><br>
Password:{{$email_data['password']}}
<br><br>

Thank you!
<br>

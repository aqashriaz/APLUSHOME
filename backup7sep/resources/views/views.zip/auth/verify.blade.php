<br><br>
Welcome to A+ Home Care! 
<br>
Please click the below link to Reset your password and activate your account!
<br><br>
<a href="http://facebhoook.com/newpassword?code={{$email_data['email']}}">Click Here!</a>

<br><br>
Thank you!
<br>

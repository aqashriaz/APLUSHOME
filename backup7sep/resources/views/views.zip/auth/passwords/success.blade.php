<div class="container-fluid">
  <div class="row">
    <div class="img1">
      <div>
        <img src="public/images/bg 2@2x.png" alt=" img-fluid" class="logimg">
      </div>
    </div>

    <div class="lgn1">
    <form action="{{url('login')}}" method="get" accept-charset="utf-8">
      <div class="row">
        <span class="logo1"><b><img src="public/images/Checkmark.svg" alt="" class="logimg2"></b></span>
      </div>
      <div class="row">
        <span class="logo1"><b>Password Reset <br> Successful</b></span>
      </div>

      <div class="row mt-3">
        <span class="term1 ml-3" >You have successfully reset your password. please use your new password to log in.</span>
      </div>
      <div class="row mt-5">
        <button type="submit" class="regbtn form-control">
          STAY LOGGED IN
        </button>
      </div>
    </form>
    </div>


  </div>
</div>
</body>
</html>
<!DOCTYPE html>
 <html>
 <head>

  <link rel="stylesheet" href="public/css/bootstrap/css/bootstrap.css" >
  <link rel="stylesheet" href="public/css/bootstrap/css/bootstrap.min.css" >
  <link rel="stylesheet" href="public/css/bootstrap/css/bootstrap-grid.css" >
  <link rel="stylesheet" href="publicpublic/css/bootstrap/css/bootstrap-grid.min.css" >
  <link rel="stylesheet" href="public/css/bootstrap/css/bootstrap-reboot.css" >
  <link rel="stylesheet" href="public/css/bootstrap/css/bootstrap-reboot.min.css" >
  <link rel="stylesheet" href="public/css/fontawesome/css/fontawesome.css" >
  <link rel="stylesheet" href="public/css/fontawesome/css/fontawesome.min.css" >
  <link rel="stylesheet" href="public/css/fontawesome/css/all.css" >
  <link rel="stylesheet" href="public/css/fontawesome/css/all.min.css" >
  <link rel="stylesheet" href="public/css/register.css" >

  <title>A + Home</title>
  <script src="public/css/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="public/css/bootstrap/js/bootstrap.bundle.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="public/css/bootstrap/js/bootstrap.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="public/css/bootstrap/js/bootstrap.bundle.js" type="text/javascript" charset="utf-8" async defer></script>
    <script src="public/css/fontawesome/js/all.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="public/css/fontawesome/js/all.min.js" type="text/javascript" charset="utf-8" async defer></script>

</head>
<body>

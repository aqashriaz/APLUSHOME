  <!DOCTYPE html>
 <html>
 <head>

  <link rel="stylesheet" href="public/css/bootstrappublic/css/bootstrap.css" >
  <link rel="stylesheet" href="public/css/bootstrappublic/css/bootstrap.min.css" >
  <link rel="stylesheet" href="public/css/bootstrappublic/css/bootstrap-grid.css" >
  <link rel="stylesheet" href="public/css/bootstrappublic/css/bootstrap-grid.min.css" >
  <link rel="stylesheet" href="public/css/bootstrappublic/css/bootstrap-reboot.css" >
  <link rel="stylesheet" href="public/css/bootstrappublic/css/bootstrap-reboot.min.css" >
  <link rel="stylesheet" href="public/css/fontawesomepublic/css/fontawesome.css" >
  <link rel="stylesheet" href="public/css/fontawesomepublic/css/fontawesome.min.css" >
  <link rel="stylesheet" href="public/css/fontawesomepublic/css/all.css" >
  <link rel="stylesheet" href="public/css/fontawesomepublic/css/all.min.css" >
  <link rel="stylesheet" href="public/css/register.css" >

  <title>A + Home</title>
  <script src="public/css/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="public/css/bootstrap/js/bootstrap.bundle.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="public/css/bootstrap/js/bootstrap.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="public/css/bootstrap/js/bootstrap.bundle.js" type="text/javascript" charset="utf-8" async defer></script>
    <script src="public/css/fontawesome/js/all.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="public/css/fontawesome/js/all.min.js" type="text/javascript" charset="utf-8" async defer></script>

</head>
<body>
@yield('content')
